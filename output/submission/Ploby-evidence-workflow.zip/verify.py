"""Verify this snapshot without the Ploby server or a private key. Exit 2 means incomplete."""
import hashlib, json, pathlib, sys
root = pathlib.Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_text())
for name, digest in manifest["files"].items():
    path = root / name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        sys.exit("Archive file missing or changed: " + name)
from escrow.audit import main
sys.argv[1:1] = [str(root / "data/projects" / manifest["project"] / "log.jsonl"), "--data", str(root / "data")]
sys.exit(main())
