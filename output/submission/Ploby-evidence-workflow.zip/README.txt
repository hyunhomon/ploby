Ploby evidence snapshot

Unzip, then run: python3 verify.py
Without network: python3 verify.py --offline
Machine-readable report: python3 verify.py --json
Wallet signatures require: python3 -m pip install -r requirements.txt
Exit codes: 0 verified, 1 inconsistent, 2 incomplete (read the reasons).

The manifest detects accidental changes to this archive. It is not an independent signature.
The verifier recomputes the recorded policy and log, checks original document hashes,
and compares recorded transactions with the public chain. E1 uploads do not establish vendor authenticity.
The live chain can have advanced since this snapshot. No private keys or API credentials are included.
